"""Python ENDESIVE library."""

__author__ = 'Grzegorz Makarewicz'
__license__ = 'MIT'
__version__ = '2.0.5'

__all__ = [__author__, __license__, __version__]
