console.log('Start background');


//Chrome
var port = chrome.runtime.connectNative("margsoft_digital_signer");

//Receive Message From Content 
chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {

	console.log(request, sender, sendResponse)


    console.log(sender.tab ?
                "from a content script:" + sender.tab.url :
                "From the extension");
	//alert("Extension Received :" +JSON.stringify(request));
   
   if (port == null)
   {
	alert("Error: Check if [Signer.Digital Extension] Application is installed.\nDownload link for Windows:\nhttps://signer.digital/downloads/Signer.Digital.Browser.Extension.Setup.msi\nVisit www.signer.digital to download Linux Hosts."); 
	return true;	//To prevent error The message port closed before a response was received.
   }
   console.log('message send to host')
   //Message to host   
   port.postMessage(request);	
   return true;	  	//To prevent error The message port closed before a response was received.
  });

//Receive Message from Host
port.onMessage.addListener(function(msg) {
  //alert("Received from host" + JSON.stringify(msg));
  
  console.log("error............")
  console.log(msg)
  //Send msg to content script
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
   chrome.tabs.sendMessage(tabs[0].id,msg, function(response) {});  
  });
  
});

port.onDisconnect.addListener(function() {
  console.log("SD Host Application Disconnected");
  port = null;
});  

