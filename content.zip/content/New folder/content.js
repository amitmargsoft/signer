console.log("CISPL SignerDigital Loaded");

//	InstallHostMsg()									\n\
//	{												\n\
//		 alert("Error: Check if [Signer.Digital Extension] Application is installed. Download link for Windows: http://signer.digital/downloads/Signer.Digital.Chrome.Host.Setup.zip");  \n\
//	}												\n\


//Get Message from Page     
window.addEventListener("message", function(event) {
  // We only accept messages from ourselves
    if (event.source !== window)
        return;

  if (event.data.src && (event.data.src === "user_page.js")) {  
	event.data["origin"] = location.origin;
	console.log("Content script received data from page : ");
	console.log(event.data);
	//Send Message to Extension
	chrome.runtime.sendMessage(event.data,function(resp){});
  }
});

//Get Message from Extension
 chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {
		//console.log(sender.tab ? "from a content script:" + sender.tab.url :"from the extension");
		console.log("Content script received from Extension : ");
		console.log(request);
        		
		//sendResponse(request);	
        // post messages to page
        request['src']="content.js";		
		window.postMessage(request, '*');
		return true;
	}
  );

	  
/////// inject content of user_page.js to the DOM of page  ///////////////
var s = document.createElement('script');
s.type = 'text/javascript';
s.innerHTML='// Promises 													\n\
var _tp_promises = {};														\n\
//Get Message From content script 											\n\
window.addEventListener("message", function(event) { 						\n\
		if(event.source !== window) return;			 						\n\
		if(event.data.src && (event.data.src === "content.js")) { 			\n\
			console.log("Page received: "); 								\n\
			console.log(event.data); 										\n\
			// Get the promise												\n\
			if(event.data.nonce) {											\n\
				 var p = _tp_promises[event.data.nonce]; 					\n\
				 // resolve													\n\
				 if(event.data.status_cd === 1){							\n\
					p.resolve(event.data.result);							\n\
				 }else{														\n\
				 	p.reject(new Error(event.data.result));					\n\
				 }															\n\
				 delete _tp_promises[event.data.nonce];						\n\
			}else {  														\n\
				console.log("No nonce in event msg");						\n\
			}																\n\
		}																	\n\
	});																		\n\
																			\n\
    var SignerDigital= new TpCrypto();										\n\
	function TpCrypto (){													\n\
																			\n\
	var OSName = GetOS();													\n\
	var OSSupported = (OSName == "Windows" || OSName == "Linux") ? true : false; \n\
	function nonce() {														\n\
	  var val = ""; 														\n\
	  var hex = "abcdefghijklmnopqrstuvwxyz0123456789";	         			\n\
	  for(var i = 0; i < 16; i++)							     			\n\
		val += hex.charAt(Math.floor(Math.random() * hex.length));			\n\
	  return val;															\n\
	}																		\n\
																			\n\
	function messagePromise(msg) { 											\n\
		return new Promise(async function(sdResolve, sdReject) { 			\n\
			if (msg["action"] == "GenCSR" || msg["action"] == "ImportCER")	\n\
			{																\n\
			   if (!OSSupported)											\n\
			   {																\n\
				 sdReject(new Error(OSName + " OS Not Supported."));	\n\
				 return;														\n\
			   }																\n\
				if(!(await checkSDEnrolledCA(msg["certIssuer"])))			\n\
				{															\n\
					sdReject(new Error("This Certifying Authority is not enrolled in Signer.Digital Browser Extension for Certificate Enrollment/Download. Contact your Certifying Authority."));	\n\
					return;													\n\
				}															\n\
			}																\n\
			// amend with necessary metadata 								\n\
			msg["nonce"] = nonce(); 										\n\
			msg["src"] = "user_page.js"; 									\n\
			msg["browser"] = "chrome"; 										\n\
			// send message 												\n\
			window.postMessage(msg, "*"); 									\n\
			// and store promise callbacks 									\n\
			_tp_promises[msg.nonce] = {										\n\
				resolve: sdResolve, 										\n\
				reject: sdReject				 							\n\
			}; 																\n\
		}); 																\n\
	}																		\n\
																			\n\
	async function checkSDEnrolledCA(certIssuer)							\n\
	{																		\n\
		var caList = ["AD5HAb+Ij2mmK1hTWpGGdK/xbGLtpQDerMJx35zmSJI=",	//CISPL Signer.Digital DEMO	\n\			//add Enrolled CA to this list	\n\
					  "VQyiIqC/d6dSmSBWTgqLxDZzb5x9eQMKBlO/MdxjeqM=",	//SafeScrypt sub-CA for RCAI \n\
					  "s2fPQ4sVgi70hCFo9S5W2HIRXT7TXsX2CwNBcAHxdPk=",	//UAT - PantaSign CA 2014 \n\
					  "tDnFOxBvx6hejWvsmFpNC6CulfWvekxWHiJKPac65Rw=",	//PantaSign CA 2014 \n\
					  "bxNw5YwP/ythQXBuv6OhWOCuPOGq1P0mz1VvCaBpaXE="];	//IDSign sub CA for Consumers 2014 \n\
		const sha256OfIssuer = await SDGetSha256(certIssuer);				\n\
		if (caList.includes(sha256OfIssuer))								\n\
			return true;													\n\
		else																\n\
			return false;													\n\
	}																		\n\
	async function SDGetSha256(message)										\n\
	{																		\n\
		// encode as UTF-8													\n\
		const msgBuffer = new TextEncoder().encode(message);				\n\
		// hash the message													\n\
		const hashBuffer = await crypto.subtle.digest("SHA-256", msgBuffer);\n\
		const bytes = new Uint8Array(hashBuffer);							\n\
		var binary = "";													\n\
		for (var i = 0; i < bytes.byteLength; i++) {						\n\
			binary += String.fromCharCode(bytes[i]);						\n\
		}																	\n\
		return window.btoa(binary);											\n\
	};																		\n\
																			\n\
	//Extension Action Methods												\n\
	this.signGstHash = function(hash, certThumbPrint = "", x509RevocationMode = 0){					\n\
		var msg= { action:"GSTReturnSign", hash:hash, certThumbPrint:certThumbPrint, x509RevocationMode:x509RevocationMode };	\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.signITHash = function(hash, PAN, certThumbPrint = "", x509RevocationMode = 0){				\n\
		var msg= { action:"ITReturnSign", hash:hash, PAN:PAN, certThumbPrint:certThumbPrint, x509RevocationMode:x509RevocationMode};	\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.signIceGate = function(b64Data, certThumbPrint = "", x509RevocationMode = 0){				\n\
		var msg= { action:"IceGateSignJson", b64Data:b64Data, certThumbPrint:certThumbPrint, x509RevocationMode:x509RevocationMode};	\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.getSelectedCertificate = function(certThumbPrint = "", showExpired = false, keyUsageFilter = 128, x509RevocationMode = 0){					\n\
		var msg= { action:"GetSelCertFromToken", certThumbPrint:certThumbPrint, showExpired:showExpired, keyUsageFilter:keyUsageFilter, x509RevocationMode:x509RevocationMode};		\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.signPdfHash = function(hash,certThumbPrint,certAlgorithm, x509RevocationMode = 0){			\n\
		var msg= { action:"PdfSignFromToken", hash:hash,certThumbPrint:certThumbPrint,hashAlgorithm:certAlgorithm, x509RevocationMode:x509RevocationMode};	\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.signAuthToken = function(authtoken, certAlgorithm, certThumbPrint = "", showExpired = false, x509RevocationMode = 0){			\n\
		var msg= { action:"SignAuthToken", authToken:authtoken, hashAlgorithm:certAlgorithm, certThumbPrint:certThumbPrint, showExpired:showExpired, x509RevocationMode:x509RevocationMode};	\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.signHash = function(hash, certAlgorithm, certThumbPrint = "", x509RevocationMode = 0){		\n\
		var msg= { action:"SignHash", hash:hash, hashAlgorithm:certAlgorithm, certThumbPrint:certThumbPrint };	\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.signHashCms = function(hash, certAlgorithm, certIncludeOptions = 2, certThumbPrint = "", x509RevocationMode = 0){		\n\
		var msg= { action:"SignHashCms", hash:hash, hashAlgorithm:certAlgorithm, certIncludeOptions:certIncludeOptions, certThumbPrint:certThumbPrint, x509RevocationMode:x509RevocationMode};	\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.signXML = function(xmlDoc, xmlSignParms, certThumbPrint, x509RevocationMode = 0){			\n\
		var msg= { action:"SignXML", xmlDoc:xmlDoc, xmlSignParms:xmlSignParms, certThumbPrint:certThumbPrint, x509RevocationMode:x509RevocationMode};	\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.encryptB64Data = function(b64Data, useOAEPPadding, certThumbPrint = "", showExpired = false, keyUsageFilter = 32, x509RevocationMode = 0){			\n\
		var msg= { action:"EncryptB64Data", b64Data:b64Data, useOAEPPadding:useOAEPPadding, certThumbPrint:certThumbPrint, showExpired:showExpired, keyUsageFilter:keyUsageFilter, x509RevocationMode:x509RevocationMode};	\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.decryptB64Data = function(b64Data, useOAEPPadding, certThumbPrint = "", showExpired = false, keyUsageFilter = 32, x509RevocationMode = 0){			\n\
		var msg= { action:"DecryptB64Data", b64Data:b64Data, useOAEPPadding:useOAEPPadding, certThumbPrint:certThumbPrint, showExpired:showExpired, keyUsageFilter:keyUsageFilter, x509RevocationMode:x509RevocationMode};	\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.getPCSCReaders = function(onlyConnected = true){				\n\
		var msg= { action:"GetPCSCReaders", onlyConnected:onlyConnected};			\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.genCSR = function(PKCS11Lib, certSubject, certIssuer, keyBits = 2048, hashAlgorithm = "SHA256", forceUserPinChangeIfDefault = false, extensions = null){				\n\
		var msg= { action:"GenCSR", PKCS11Lib:PKCS11Lib, certSubject:certSubject, certIssuer:certIssuer, keyBits:keyBits, hashAlgorithm:hashAlgorithm, forceUserPinChangeIfDefault:forceUserPinChangeIfDefault, extensions:extensions};			\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.importCer = function(PKCS11Lib, b64Payload, certIssuer){		\n\
		var msg= { action:"ImportCER", PKCS11Lib:PKCS11Lib, b64Data:b64Payload, certIssuer:certIssuer};		\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.getHostDetails = function(){										\n\
		var msg= { action:"GetHostDetails"};								\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.sm = function(msg){												\n\
		return messagePromise(msg);											\n\
	}																		\n\
	this.OSName = GetOS();													\n\
	this.OSSupported = (this.OSName == "Windows" || this.OSName == "Linux") ? true : false; \n\
	this.getPkcsLibByProvider = function(ProviderName)								\n\
        {																	\n\
            let winHashMap = new Map([										\n\
                ["EnterSafe ePass2003 CSP v2.0", "eps2003csp11v2.dll"],		\n\
                ["eToken Base Cryptographic Provider", "eTPKCS11.dll"],		\n\
                ["PROXKey CSP India V1.0", "SignatureP11.dll"],				\n\
                ["Bit4id Universal Middleware Provider", "bit4ipki.dll"],	\n\
                ["mToken CryptoID CSP", "CryptoIDA_pkcs11.dll"] 			\n\
            ]);																\n\
            let linuxHashMap = new Map([									\n\
                ["EnterSafe ePass2003 CSP v2.0", "libcastle_v2.so.1.0.0"],					\n\
                ["eToken Base Cryptographic Provider", "libeTPkcs11.so"],				\n\
                ["PROXKey CSP India V1.0", "libwdpkcs_SignatureP11.so"],							\n\
                ["mToken CryptoID CSP", "libcryptoid_pkcs11.so"]							\n\
            ]);																\n\
			var providerNotEnrolledMsg = "Provider Not enrolled in Signer.Digital Browser Extension. Can still be used by passing pkcs#11 driver lib name in PKCS11Lib param."	 \n\
            if (this.OSName == "Windows") {										\n\
                if (ProviderName.startsWith("Microsoft"))					\n\
                    return ProviderName;									\n\
                else if (winHashMap.has(ProviderName))				\n\
                    return winHashMap.get(ProviderName);					\n\
				else														\n\
					return providerNotEnrolledMsg; 	\n\
            }																\n\
            if (this.OSName = "Linux") {											\n\
				if (linuxHashMap.has(ProviderName))							\n\
					return linuxHashMap.get(ProviderName);					\n\
				else														\n\
					return providerNotEnrolledMsg; 							\n\
			}																\n\
			else {															\n\
                return "OS Not Supported";									\n\
            }																\n\
        }																	\n\
	this.getPkcsLibBySCName = function(SCName)								\n\
        {																	\n\
            let winHashMap = new Map([										\n\
                ["HyperSecu ePass2003", "eps2003csp11v2.dll"],				\n\
                ["SafeNet eToken", "eTPKCS11.dll"],							\n\
                ["PROXKey Watchdata", "SignatureP11.dll"],					\n\
                ["Bit4id tokenME", "bit4ipki.dll"],							\n\
                ["Longmai mToken", "CryptoIDA_pkcs11.dll"],					\n\
                ["Gemalto USB", ".dll"]						\n\
            ]);																\n\
            let linuxHashMap = new Map([									\n\
                ["HyperSecu ePass2003", "libcastle_v2.so.1.0.0"],					\n\
                ["SafeNet eToken", "/usr/lib/libeTPkcs11.so"],				\n\
                ["PROXKey Watchdata", "/usr/lib/WatchData/ProxKey/lib/libwdpkcs_SignatureP11.so"],							\n\
                ["Longmai mToken", "/opt/CryptoIDATools/bin/lib/libcryptoid_pkcs11.so"]							\n\
            ]);																\n\
			var SCNotEnrolledMsg = "Smartcard Not enrolled in Signer.Digital Browser Extension. Can still be used by passing pkcs#11 driver lib name in PKCS11Lib param."	 \n\
            if (this.OSName == "Windows") {										\n\
                if (SCName == "Windows Certificate Store")					\n\
                    return "Microsoft Enhanced RSA and AES Cryptographic Provider";									\n\
                else if (winHashMap.has(SCName))				\n\
                    return winHashMap.get(SCName);					\n\
				else														\n\
					return SCNotEnrolledMsg; 	\n\
            }																\n\
            if (this.OSName = "Linux") {											\n\
				if (linuxHashMap.has(SCName))							\n\
					return linuxHashMap.get(SCName);					\n\
				else														\n\
					return SCNotEnrolledMsg; 							\n\
			}																\n\
			else {															\n\
                return "OS Not Supported";									\n\
            }																\n\
        }																	\n\
	this.getSCNameByReaderName = function(ReaderName)						\n\
        {																	\n\
            let winHashMap = new Map([										\n\
                ["HYPERSECU USB TOKEN 0", "HyperSecu ePass2003"],			\n\
                ["FT ePass2003Auto 0", "HyperSecu ePass2003"],				\n\
                ["FS USB Token 0", "HyperSecu ePass2003"],					\n\
				["feitian ePass2003 0", "HyperSecu ePass2003"],             \n\
                ["AKS ifdh 0", "SafeNet eToken"],							\n\
                ["AKS ifdh 1", "SafeNet eToken"],							\n\
                ["SafeNet Token JC 0", "SafeNet eToken"],					\n\
                ["SafeNet Token JC 1", "SafeNet eToken"],					\n\
                ["Aladdin Token JC 0", "SafeNet eToken"],					\n\
                ["Aladdin Token JC 1", "SafeNet eToken"],					\n\
                ["Watchdata WDIND USB CCID Key 0", "PROXKey Watchdata"],	\n\
                ["Bit4id tokenME FIPS 0", "Bit4id tokenME"],				\n\
                ["Longmai mToken CryptoIDA 0", "Longmai mToken"],			\n\
				["Gemplus USB SmartCard Reader 0", "Gemalto USB"]			\n\
            ]);																\n\
            let linuxHashMap = new Map([									\n\
                ["Feitian ePass2003", "HyperSecu ePass2003"],				\n\
                ["FT ePass2003Auto", "HyperSecu ePass2003"],				\n\
                ["SafeNet eToken 5100", "SafeNet eToken"],					\n\
                ["Watchdata USB Key", "PROXKey Watchdata"]					\n\
            ]);																\n\
            if (this.OSName == "Windows") {									\n\
                if (winHashMap.has(ReaderName))								\n\
                    return winHashMap.get(ReaderName);						\n\
				else														\n\
					return ReaderName; 	\n\
            }																\n\
            if (this.OSName = "Linux") {											\n\
				if (linuxHashMap.has(ReaderName))							\n\
					return linuxHashMap.get(ReaderName);					\n\
				else														\n\
					return ReaderName; 							\n\
			}																\n\
			else {															\n\
                return ReaderName;									\n\
            }																\n\
        }																	\n\
		function GetOS()													\n\
		{																	\n\
            if (navigator.appVersion.indexOf("Win") != -1) return "Windows";\n\
            else if (navigator.appVersion.indexOf("Mac") != -1) return "MacOS";	\n\
            else if (navigator.appVersion.indexOf("X11") != -1) return "UNIX";	\n\
            else if (navigator.appVersion.indexOf("Linux") != -1) return "Linux";\n\
			else return "Unknown OS";										\n\
		}																	\n\
}//End of TpCrypto class													\n\
';
(document.head || document.documentElement).appendChild(s);



